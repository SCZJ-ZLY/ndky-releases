# -*- coding: utf-8 -*-
"""NDKY 经济测算工作簿生成与填充（0.6.0）。

经济测算.xlsx 三张 sheet：
- 投资估算：工程费/设备购置/其他费用/预备费/建设期利息/流动资金 → 总投资；
  合价=数量×单价 公式预置，小计/总投资公式联动；
- 财务评价：参数区（产量/单价/年运营成本/基准收益率/计算期/建设期）+
  0~10 年现金流表（流入/流出/净额/累计，公式联动）+ IRR/NPV/回收期/投资利润率；
- 口径说明：计算口径与参数（基本预备费率被投资估算表引用）+ 数据来源登记。

用法：
  python gen_econ_workbook.py --template <输出.xlsx>        # 生成空白模板
  python gen_econ_workbook.py --fill <工作簿.xlsx> <数据.json>  # 向现有表填数

--fill 只写空白单元格，绝不覆盖已有值（保护人工确认数据）。数据 JSON 结构：
{
  "投资估算": [
    {"section": "一", "科目": "…", "内容": "…", "单位": "…", "数量": 1,
     "单价": 2, "资金来源": "自筹", "来源": "资料文件名+位置", "备注": ""},
    ...],
  "固定项": {"建设期利息": {"值": 0, "来源": "…"}, "铺底流动资金": {"值": 0, "来源": "…"}},
  "参数": {"年设计产量": 180, "产品出厂单价": 2.5, "年运营成本": 22},
  "参数来源": {"年设计产量": "资料文件名+位置"}
}
"""
import json
import sys
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")

HEADER_FILL = PatternFill("solid", fgColor="2F5B3C")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
GROUP_FILL = PatternFill("solid", fgColor="E8F0EA")
GROUP_FONT = Font(name="微软雅黑", size=10, bold=True, color="2F5B3C")
TOTAL_FILL = PatternFill("solid", fgColor="D9E8DD")
TOTAL_FONT = Font(name="微软雅黑", size=10, bold=True, color="2F5B3C")
BODY_FONT = Font(name="微软雅黑", size=10)
TIP_FONT = Font(name="微软雅黑", size=9, color="808080")
THIN = Side(style="thin", color="C0C0C0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(vertical="center", wrap_text=True)

# 投资估算固定行号（1 起算；列 A序号 B科目 C内容 D单位 E数量 F单价 G合价 H资金来源 I来源 J状态 K备注）
SEC_ROWS = {"一": (3, 7), "二": (10, 13), "三": (16, 19)}
ROW_SUB1, ROW_SUB2, ROW_SUB3 = 8, 14, 20
ROW_PREPARE, ROW_INTEREST, ROW_WORKCAP, ROW_TOTAL = 22, 23, 24, 25
ROW_IN_TIP = 27
# 财务评价固定行号（参数 C 列=数值；现金流 B..L = 第0~10年）
PARAM_ROWS = {"年设计产量": 2, "产品出厂单价": 3, "年运营成本": 4,
              "基准收益率 ic": 5, "计算期": 6, "建设期": 7}
ROW_CF_HEADER, ROW_INFLOW, ROW_OUTFLOW, ROW_NET, ROW_CUM = 9, 10, 11, 12, 13
ROW_IRR, ROW_NPV, ROW_PAYBACK, ROW_PROFIT_RATE = 15, 16, 17, 18


def _style_header(ws, row, columns):
    for col in range(1, columns + 1):
        c = ws.cell(row=row, column=col)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER


def _group_row(ws, row, text, columns):
    c = ws.cell(row=row, column=1, value=text)
    c.fill = GROUP_FILL
    c.font = GROUP_FONT
    for col in range(1, columns + 1):
        ws.cell(row=row, column=col).border = BORDER


def _body_cell(ws, row, col, value=None):
    c = ws.cell(row=row, column=col)
    if value is not None:
        c.value = value
    c.font = BODY_FONT
    c.border = BORDER
    c.alignment = WRAP
    return c


def build_invest_sheet(wb):
    ws = wb.active
    ws.title = "投资估算"
    headers = ["序号", "费用科目", "建设内容/规格", "单位", "数量", "单价（元）",
               "合价（万元）", "资金来源", "来源", "状态", "备注"]
    for col, name in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=name)
    _style_header(ws, 1, len(headers))

    sections = [
        ("一、工程建设费（土建/田间工程/附属设施，无内容的节可整节留空）", "一", 3, 7),
        ("二、设备购置及安装费", "二", 10, 13),
        ("三、其他费用（前期工作/勘察设计/监理/管理费等）", "三", 16, 19),
    ]
    for text, key, r0, r1 in sections:
        _group_row(ws, r0 - 1, text, len(headers))
        for r in range(r0, r1 + 1):
            for col in range(1, len(headers) + 1):
                v = None
                if col == 7:
                    v = f'=IF(OR($E{r}="",$F{r}=""),"",$E{r}*$F{r}/10000)'
                elif col == 10:
                    v = "待确认"
                _body_cell(ws, r, col, v)
            ws.cell(row=r, column=7).number_format = "0.00"
        sub = _body_cell(ws, r1 + 1, 2, f"小计（{key}）")
        sub.font = TOTAL_FONT
        g = _body_cell(ws, r1 + 1, 7, f"=SUM(G{r0}:G{r1})")
        g.font = TOTAL_FONT
        g.number_format = "0.00"
        for col in range(1, len(headers) + 1):
            c = ws.cell(row=r1 + 1, column=col)
            c.fill = TOTAL_FILL
            c.border = BORDER

    # 四、预备费及其他（行 21 组头；22-24 固定行；25 总投资）
    _group_row(ws, 21, "四、预备费及其他", len(headers))
    prep = _body_cell(ws, ROW_PREPARE, 2, "基本预备费")
    prep.font = BODY_FONT
    g = _body_cell(ws, ROW_PREPARE, 7,
                   f"=ROUND((G{ROW_SUB1}+G{ROW_SUB2}+G{ROW_SUB3})*'口径说明'!$B$2/100,2)")
    g.number_format = "0.00"
    _body_cell(ws, ROW_PREPARE, 9, "口径：费率见「口径说明」表（默认 5%）")
    _body_cell(ws, ROW_PREPARE, 10, "待确认")
    for name, row in [("建设期利息", ROW_INTEREST), ("铺底流动资金", ROW_WORKCAP)]:
        _body_cell(ws, row, 2, name)
        g = _body_cell(ws, row, 7)
        g.number_format = "0.00"
        _body_cell(ws, row, 9, "")
        _body_cell(ws, row, 10, "待确认")
    total = _body_cell(ws, ROW_TOTAL, 2, "总投资（万元）")
    total.font = TOTAL_FONT
    g = _body_cell(ws, ROW_TOTAL, 7,
                   f"=G{ROW_SUB1}+G{ROW_SUB2}+G{ROW_SUB3}+G{ROW_PREPARE}+G{ROW_INTEREST}+G{ROW_WORKCAP}")
    g.font = TOTAL_FONT
    g.number_format = "0.00"
    for col in range(1, len(headers) + 1):
        c = ws.cell(row=ROW_TOTAL, column=col)
        c.fill = TOTAL_FILL
        c.border = BORDER

    tip = ws.cell(row=ROW_IN_TIP, column=1,
                  value="填写说明：合价/小计/总投资为公式自动计算，请勿手改公式列；每个数字的「来源」列必须写出处"
                        "（资料文件名+工作表/行，或账本编号）；资料里没有的行留空，严禁估数。插行后请自查小计 SUM 范围。"
                        "AI 填数用 --fill 模式（只填空格，不覆盖人工已填数据）。")
    tip.font = TIP_FONT
    widths = [7, 26, 28, 8, 10, 12, 13, 12, 26, 9, 22]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


def build_financial_sheet(wb):
    ws = wb.create_sheet("财务评价")
    # 参数区
    for col, name in enumerate(["参数", "数值", "单位", "来源", "说明"], 1):
        ws.cell(row=1, column=col, value=name)
    _style_header(ws, 1, 5)
    params = [
        ("年设计产量", None, "吨/年（或按项目实际产品口径）", "", "与单价单位配套"),
        ("产品出厂单价", None, "元/公斤（或与产量口径配套）", "", "达产年口径"),
        ("年运营成本", None, "万元/年", "", "外购原材料/人工/水电/运维等合计"),
        ("基准收益率 ic", 6, "%", "通用默认", "可按甲方口径调整"),
        ("计算期", 10, "年", "通用默认", "含建设期；现金流表支持第 0~10 年"),
        ("建设期", 1, "年", "", "该期内现金流入按 0 计；总投资默认计于第 0 年"),
    ]
    for name, value, unit, source, note in params:
        r = PARAM_ROWS[name]
        _body_cell(ws, r, 1, name)
        _body_cell(ws, r, 2, value)
        _body_cell(ws, r, 3, unit)
        _body_cell(ws, r, 4, source)
        _body_cell(ws, r, 5, note)

    # 现金流表（第 0~10 年 → B..L 共 11 列）
    _group_row(ws, ROW_CF_HEADER - 1, "现金流表（万元，公式自动计算；灰字为公式列请勿手改）", 12)
    hdr = _body_cell(ws, ROW_CF_HEADER, 1, "项目")
    hdr.font = HEADER_FONT
    hdr.fill = HEADER_FILL
    for y in range(0, 11):
        c = _body_cell(ws, ROW_CF_HEADER, 2 + y, f"第{y}年")
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")

    flows = [
        (ROW_INFLOW, "现金流入"),
        (ROW_OUTFLOW, "现金流出"),
        (ROW_NET, "净现金流"),
        (ROW_CUM, "累计净现金流"),
    ]
    for row, label in flows:
        _body_cell(ws, row, 1, label)
    for y in range(0, 11):
        col = 2 + y
        L = get_column_letter(col)
        if y == 0:
            _body_cell(ws, ROW_INFLOW, col, 0)
            _body_cell(ws, ROW_OUTFLOW, col, "=投资估算!$G$%d" % ROW_TOTAL)
        else:
            _body_cell(ws, ROW_INFLOW, col, f"=IF({y}<=$C$7,0,$C$2*$C$3/10)")
            _body_cell(ws, ROW_OUTFLOW, col, "=$C$4")
        _body_cell(ws, ROW_NET, col, f"={L}{ROW_INFLOW}-{L}{ROW_OUTFLOW}")
        prev = get_column_letter(col - 1)
        _body_cell(ws, ROW_CUM, col, f"={prev}{ROW_CUM}+{L}{ROW_NET}" if y else f"={L}{ROW_NET}")
        for row in (ROW_INFLOW, ROW_OUTFLOW, ROW_NET, ROW_CUM):
            ws.cell(row=row, column=col).number_format = "0.00"

    # 指标区
    _group_row(ws, ROW_IRR - 1, "评价指标（参数填齐后自动重算；显示错误=参数未填齐）", 6)
    indicators = [
        (ROW_IRR, "IRR（%）", f"=IFERROR(IRR(B{ROW_NET}:L{ROW_NET})*100,\"—\")"),
        (ROW_NPV, "NPV（万元）", f"=IFERROR(NPV($C$5/100,C{ROW_NET}:L{ROW_NET})+B{ROW_NET},\"—\")"),
        (ROW_PAYBACK, "静态投资回收期（含建设期·年）",
         f"=IFERROR(COUNTIF(B{ROW_CUM}:L{ROW_CUM},\"<0\")-1"
         f"+ABS(INDEX(B{ROW_CUM}:L{ROW_CUM},COUNTIF(B{ROW_CUM}:L{ROW_CUM},\"<0\")))"
         f"/INDEX(B{ROW_NET}:L{ROW_NET},COUNTIF(B{ROW_CUM}:L{ROW_CUM},\"<0\")+1),\"—\")"),
        (ROW_PROFIT_RATE, "投资利润率（%）",
         f"=IFERROR(($C$2*$C$3/10-$C$4)/投资估算!$G${ROW_TOTAL}*100,\"—\")"),
    ]
    for row, label, formula in indicators:
        _body_cell(ws, row, 1, label)
        c = _body_cell(ws, row, 2, formula)
        c.number_format = "0.00"

    tip = ws.cell(row=ROW_PROFIT_RATE + 2, column=1,
                  value="填写说明：只需填参数区空白项（B 列），现金流与指标全部公式自动重算；"
                        "测算结果仅为辅助参考，最终数值以甲方专业人员复核确认为准（需求确认书 4.3）。")
    tip.font = TIP_FONT
    widths = [26, 12, 10, 12, 12, 12, 12, 12, 12, 12, 12, 12]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "B2"


def build_caliber_sheet(wb):
    ws = wb.create_sheet("口径说明")
    for col, name in enumerate(["口径项", "数值", "单位/说明", "来源", "状态"], 1):
        ws.cell(row=1, column=col, value=name)
    _style_header(ws, 1, 5)
    rows = [
        ("基本预备费率", 5, "%（×（一+二+三）小计之和），被投资估算表引用", "通用默认", "待确认"),
        ("基准收益率 ic", 6, "%（财务评价表参数，两处保持一致）", "通用默认", "待确认"),
        ("折旧与摊销", "", "运营成本已含或需单列，按甲方口径", "待甲方确认", "待确认"),
        ("运营成本构成", "", "外购原材料/燃料动力/人工/维修/其他，逐项依据见数据来源清单", "待提取", "待确认"),
        ("产品与产能口径", "", "达产年口径；分年爬坡若无资料按达产年简化", "待甲方确认", "待确认"),
    ]
    for i, (a, b, c, d, e) in enumerate(rows, 2):
        _body_cell(ws, i, 1, a)
        _body_cell(ws, i, 2, b)
        _body_cell(ws, i, 3, c)
        _body_cell(ws, i, 4, d)
        _body_cell(ws, i, 5, e)

    _group_row(ws, 8, "数据来源登记（AI 提取/人工补充时逐条登记，与各表「来源」列对应）", 5)
    for col, name in enumerate(["资料文件", "提取内容", "用途（哪行哪参数）", "日期", "登记人"], 1):
        ws.cell(row=9, column=col, value=name)
    _style_header(ws, 9, 5)
    for r in range(10, 20):
        for col in range(1, 6):
            _body_cell(ws, r, col)
    tip = ws.cell(row=21, column=1,
                  value="填写说明：甲方确认的口径把「状态」改「已确认」；与通用默认不一致时以甲方口径为准并回改对应表格参数。")
    tip.font = TIP_FONT
    widths = [22, 12, 46, 20, 10]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


def do_template(out: Path):
    out.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    build_invest_sheet(wb)
    build_financial_sheet(wb)
    build_caliber_sheet(wb)
    wb.save(out)
    print(f"已生成模板 {out}")


def do_fill(xlsx: Path, data_path: Path):
    data = json.loads(data_path.read_text(encoding="utf-8"))
    wb = load_workbook(xlsx)
    ws_inv = wb["投资估算"]
    ws_fin = wb["财务评价"]
    filled, skipped = [], []

    def put(ws, row, col, value, label):
        cell = ws.cell(row=row, column=col)
        if cell.value not in (None, ""):
            skipped.append(f"{label}（已有值：{str(cell.value)[:20]}）")
            return
        cell.value = value
        filled.append(label)

    # 投资估算明细行（先按科目名去重：已存在同名科目=已录入，跳过保护；否则找第一个空行）
    for item in data.get("投资估算", []):
        sec = str(item.get("section", "")).strip()
        if sec not in SEC_ROWS:
            skipped.append(f"投资估算[{item.get('科目')}]（section 须为一/二/三）")
            continue
        r0, r1 = SEC_ROWS[sec]
        subject = str(item.get("科目") or "").strip()
        dup = None
        target = None
        for r in range(r0, r1 + 1):
            existing = str(ws_inv.cell(row=r, column=2).value or "").strip()
            if subject and existing == subject:
                dup = r
                break
            if target is None and existing == "":
                target = r
        if dup is not None:
            skipped.append(f"投资估算!B{dup} [{subject}]（同名科目已存在，保护不重复录入）")
            continue
        if target is None:
            skipped.append(f"投资估算[{subject}]（第{sec}节空行已满，请人工插行）")
            continue
        put(ws_inv, target, 2, item.get("科目"), f"投资估算!B{target} 科目")
        for col, key in [(3, "内容"), (4, "单位"), (5, "数量"), (6, "单价"),
                         (8, "资金来源"), (9, "来源"), (11, "备注")]:
            if item.get(key) not in (None, ""):
                put(ws_inv, target, col, item[key], f"投资估算!{get_column_letter(col)}{target}")

    # 固定行（建设期利息/铺底流动资金）
    fixed_rows = {"建设期利息": ROW_INTEREST, "铺底流动资金": ROW_WORKCAP}
    for name, info in (data.get("固定项") or {}).items():
        row = fixed_rows.get(name)
        if row is None:
            skipped.append(f"固定项[{name}]（未知项）")
            continue
        if info.get("值") not in (None, ""):
            put(ws_inv, row, 7, info["值"], f"投资估算!G{row} {name}")
        if info.get("来源"):
            put(ws_inv, row, 9, info["来源"], f"投资估算!I{row} {name} 来源")

    # 财务评价参数（只填空白；默认参数不被空 JSON 覆盖）
    for name, value in (data.get("参数") or {}).items():
        row = PARAM_ROWS.get(name)
        if row is None:
            skipped.append(f"参数[{name}]（未知参数）")
            continue
        put(ws_fin, row, 2, value, f"财务评价!B{row} {name}")
    for name, source in (data.get("参数来源") or {}).items():
        row = PARAM_ROWS.get(name)
        if row is not None and source:
            put(ws_fin, row, 4, source, f"财务评价!D{row} {name} 来源")

    wb.save(xlsx)
    print(f"已填 {len(filled)} 格：")
    for f in filled:
        print("  +", f)
    if skipped:
        print(f"跳过 {len(skipped)} 格（保护已有值/未知项）：")
        for s in skipped:
            print("  -", s)
    if not filled:
        print("注意：本次没有任何单元格被填写。")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)
    if args[0] == "--template":
        if len(args) < 2:
            print("用法：gen_econ_workbook.py --template <输出.xlsx>")
            sys.exit(1)
        do_template(Path(args[1]))
    elif args[0] == "--fill":
        if len(args) < 3:
            print("用法：gen_econ_workbook.py --fill <工作簿.xlsx> <数据.json>")
            sys.exit(1)
        do_fill(Path(args[1]), Path(args[2]))
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
