# -*- coding: utf-8 -*-
"""NDKY 文档生成：在标准模板上按大纲填文本，格式通过模板自定义样式继承。

原理：
- 三份 0731 标准模板各自带成套自定义样式（主标题/章节标题/子节标题/正文/封面目录），
  字体、字号、首行缩进、行距均已在样式内定义好；
- 本脚本读模板 → 按大纲层级把标题/正文写入并套对应**角色样式** → 另存；
- 角色到样式名的映射按候选清单自动匹配（三份模板样式名不同）；
- 全程 python-docx 对象 API，不手写 OOXML。

用法：
  python fill_template.py --outline 章节.md --out 产出.docx [--template 模板.docx] [--title 文档题名] [--append]

默认模板：农业项目策划文本规范框架（2）（0731）——农大科源主力文体。
可用 --template 换成框架（1）或可研通用大纲（0731）。

默认模式（整卷生成）：清空模板正文后按大纲重建——**只用于标准模板或空白基底，
严禁对含内容的初稿用默认模式（会清掉全部内容）**。
--append 模式（初稿续写）：不清空正文，把大纲内容**追加到文档末尾**，样式按
初稿自身样式表的角色匹配（用于给初稿工作稿补写整章）。
初稿中段插入内容不用本脚本，由 agent 用 python-docx 在指定位置原位插入、
套初稿同类层级样式。

outline 格式（markdown 前缀 = 角色层级）：
  #    → 第一个为文档题名（主标题样式），其余为章标题
  ##   → 节标题
  ###/#### → 正文（三级条目按规范同正文排版）
  普通段落 → 正文
  > 开头 → 正文但无首行缩进（表格引言等）
  ~ 开头 → 封面/扉页/目录行（封面目录样式）
"""
import argparse
import re
import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt

sys.stdout.reconfigure(encoding="utf-8")

PLUGIN_ROOT = Path(__file__).resolve().parents[3]
TPL_DIR = PLUGIN_ROOT / "templates" / "项目工作区" / "模板"
DEFAULT_TEMPLATE = TPL_DIR / "农业项目策划文本规范框架（2）（0731）.docx"
STANDARD_TEMPLATES = [
    TPL_DIR / "农业项目策划文本规范框架（1）（0731）.docx",
    TPL_DIR / "农业项目策划文本规范框架（2）（0731）.docx",
    TPL_DIR / "可研通用大纲（0731）.docx",
]

# 角色 → 各模板候选样式名（按三份 0731 标准模板的实际样式表；末位兜底内置样式名）
ROLE_CANDIDATES = {
    "title":    ["主标题-农业项目策划", "可研主标题", "Title"],
    "chapter":  ["章节标题-农业项目策划", "可研章节标题", "Heading 1"],
    "section":  ["子节标题-农业项目策划", "可研子节标题", "Heading 2"],
    "body":     ["正文-农业项目策划", "可研正文", "Normal"],
    "cover":    ["封面扉页目录-农业项目策划", "封面目录-农业项目策划", "可研副标题"],
}


def resolve_roles(doc):
    """把角色解析为该文档实际存在的样式名；返回 {role: style_name}。"""
    have = {s.name for s in doc.styles}
    roles = {}
    for role, candidates in ROLE_CANDIDATES.items():
        for name in candidates:
            if name in have:
                roles[role] = name
                break
    for role in ("title", "chapter", "section", "body"):
        if role not in roles:
            print(f"!! 模板缺少角色样式：{role}（候选 {ROLE_CANDIDATES[role]} 均不存在）")
            sys.exit(3)
    if "cover" not in roles:
        roles["cover"] = roles["body"]  # 无封面样式时按正文排
    return roles


def parse_outline(md_path: Path):
    """返回 [(kind, text)]；kind: title/chapter/section/body/body_noindent/cover。
    第一个 # 为题名，其余 # 为章；### 及以下按正文。"""
    items = []
    first_h1_seen = False
    for raw in md_path.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            level, text = len(m.group(1)), m.group(2).strip()
            if level == 1:
                if not first_h1_seen:
                    first_h1_seen = True
                    items.append(("title", text))
                else:
                    items.append(("chapter", text))
            elif level == 2:
                items.append(("section", text))
            else:  # 三级条目按规范同正文
                items.append(("body", text))
            continue
        stripped = line.lstrip()
        if stripped.startswith("~"):
            items.append(("cover", stripped.lstrip("~").strip()))
        elif stripped.startswith(">"):
            items.append(("body_noindent", stripped.lstrip(">").strip()))
        else:
            items.append(("body", line.strip()))
    return items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", default=str(DEFAULT_TEMPLATE),
                    help="基底模板 docx；默认: 框架（2）（0731）主力文体")
    ap.add_argument("--outline", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default=None, help="覆盖文档题名（替换大纲第一个 # 的文字）")
    ap.add_argument("--append", action="store_true",
                    help="追加模式：不清空正文，把大纲内容加到文档末尾（初稿续写补整章用）")
    ap.add_argument("--force", action="store_true",
                    help="默认模式下对含实质内容的非内置模板基底强制清空重建（自担数据风险）")
    args = ap.parse_args()

    tpl = Path(args.template)
    if not tpl.exists():
        print(f"!! 找不到基底模板：{tpl}")
        print("   内置三份标准模板：")
        for t in STANDARD_TEMPLATES:
            print(f"   - {t}")
        sys.exit(2)

    doc = Document(str(tpl))
    roles = resolve_roles(doc)
    items = parse_outline(Path(args.outline))
    if args.title:
        items = [(k, args.title) if k == "title" else (k, t) for k, t in items]

    # 基底内容保护：默认模式只允许内置标准模板（其正文是框架占位说明，清空重建即预期行为）
    is_standard = tpl.resolve() in {t.resolve() for t in STANDARD_TEMPLATES}
    has_content = any(p.text.strip() for p in doc.paragraphs)
    if args.append:
        if not has_content:
            print("!! --append 用于在已有内容上追加，但基底文档正文为空；整卷生成请去掉 --append")
            sys.exit(4)
    elif has_content and not is_standard and not args.force:
        print(f"!! 基底文档含实质内容且不是内置标准模板：{tpl.name}")
        print("   默认模式会清空全部内容重建。初稿续写请改用 --append；确认清空请加 --force。")
        sys.exit(5)
    if not args.append:
        # 清空模板正文（保留 styles/sections/页眉页脚），按大纲重建
        body = doc.element.body
        for child in list(body):
            if child.tag.endswith("}sectPr"):
                continue
            body.remove(child)

    for kind, text in items:
        if kind in roles:  # title/chapter/section/body/cover
            p = doc.add_paragraph(text, style=roles[kind])
        else:  # body_noindent
            p = doc.add_paragraph(text, style=roles["body"])
            p.paragraph_format.first_line_indent = Pt(0)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out))
    style_summary = "，".join(f"{r}→{n}" for r, n in roles.items())
    print(f"已生成 {out}")
    print(f"  基底模板：{tpl.name}")
    print(f"  样式映射：{style_summary}")
    print(f"  内容块数：{len(items)}")


if __name__ == "__main__":
    main()
