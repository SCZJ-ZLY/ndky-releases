# -*- coding: utf-8 -*-
"""NDKY 资料转文本：把 资料/ 下的 docx 抽取为纯文本到 资料/_texts/，供全文检索。
PDF/图片不处理（由 agent 用官方 pdf 技能读取，或人工转换后放入 资料/）。
用法：python extract_texts.py <项目目录>
"""
import re
import sys
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<w:tab[^>]*/>", "\t", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src_dir = Path(sys.argv[1]) / "资料"
    if not src_dir.exists():
        print(f"!! 找不到资料目录：{src_dir}")
        sys.exit(2)
    out_dir = src_dir / "_texts"
    out_dir.mkdir(exist_ok=True)

    done, skipped = [], []
    for f in sorted(src_dir.iterdir()):
        if not f.is_file():
            continue
        if f.suffix.lower() == ".docx" and not f.name.startswith("~$"):
            text = docx_text(f)
            (out_dir / (f.stem + ".txt")).write_text(text, encoding="utf-8")
            done.append(f"{f.name} → {len(text)} 字")
        elif f.suffix.lower() in (".txt", ".md"):
            continue  # 本身就是文本
        else:
            skipped.append(f.name)

    print(f"已抽取 {len(done)} 个 docx → 资料/_texts/")
    for line in done:
        print("  ", line)
    if skipped:
        print(f"跳过 {len(skipped)} 个非 docx 文件（PDF/图片请用官方 pdf 技能读取）：")
        for name in skipped[:20]:
            print("  -", name)


if __name__ == "__main__":
    main()
