# -*- coding: utf-8 -*-
"""NDKY 项目基础信息表模板生成（0.4.0）：生成 templates/项目工作区/项目基础信息.xlsx。

三张 sheet：
- 基础信息：字段/填写值/状态/来源/备注 —— 第一阶段 AI 提取+用户审核的主战场；
- 事实账本：承接原账本.md 的全部纪律（三态+来源），报告正文数字的唯一来源；
- 待补充清单：缺失数据登记（标准交付物之一）。

用法：python gen_basic_info_template.py <输出路径.xlsx>
"""
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")

HEADER_FILL = PatternFill("solid", fgColor="2F5B3C")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
GROUP_FILL = PatternFill("solid", fgColor="E8F0EA")
GROUP_FONT = Font(name="微软雅黑", size=10, bold=True, color="2F5B3C")
BODY_FONT = Font(name="微软雅黑", size=10)
TIP_FONT = Font(name="微软雅黑", size=9, color="808080")
THIN = Side(style="thin", color="C0C0C0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(vertical="center", wrap_text=True)

# 基础信息字段集（按三文体"项目总论"口径；状态列初始待确认，来源列由 AI 提取时填写）
BASIC_FIELDS = [
    ("一、项目身份", None, None),
    ("项目名称（全称）", "", "与批复/营业执照一致"),
    ("项目简称", "", "报告行文用"),
    ("报告文体", "", "①策划文本 ②可研级策划文本 ③可研报告"),
    ("二、实施主体", None, None),
    ("实施主体（全称）", "", "营业执照全称"),
    ("统一社会信用代码", "", ""),
    ("主体性质", "", "国企/民企/合作社/村集体/联合体"),
    ("联系人及电话", "", ""),
    ("三、选址与用地", None, None),
    ("建设地点", "", "精确到镇（街道）、村"),
    ("用地总规模（亩）", "", "区分耕地/设施农业用地/建设用地"),
    ("用地取得方式与年限", "", "流转/租赁/自有，年限"),
    ("四、规模与内容", None, None),
    ("建设内容概述", "", "一句话总述"),
    ("核心建设规模指标", "", "如：大棚X亩/加工车间X㎡/存栏X头"),
    ("主要产业方向", "", ""),
    ("五、投资与资金", None, None),
    ("总投资（万元）", "", "分工程费/其他费/预备费/流动资金"),
    ("资金来源结构", "", "财政/自筹/贷款/社会资本及占比"),
    ("六、周期与进度", None, None),
    ("建设周期（月）", "", "统一 24/36 个月口径，不写固定年份"),
    ("分期安排", "", "筹备/施工/投产运营各多久"),
    ("七、效益与联农带农", None, None),
    ("带动就业（人）", "", ""),
    ("联农带农机制", "", "订单/务工/入股/租赁等"),
    ("带动农户数（户）与增收（万元/年）", "", ""),
    ("村集体增收（万元/年）", "", ""),
    ("主要效益预期", "", "经济/社会/生态一句话各一"),
]

LEDGER_HEADERS = ["编号", "字段/事实", "数值", "单位", "状态", "来源", "报告使用位置", "备注"]
LEDGER_STATUS_TIP = "状态只允许：confirmed（已确认）/ candidate（待确认）/ conflict（冲突待裁决）"

TODO_HEADERS = ["缺失项", "用途（报告哪节需要）", "建议来源/找谁要", "状态", "备注"]
TODO_STATUS_TIP = "状态：待补充 / 已补充"


def style_header_row(ws, row, columns):
    for col in range(1, columns + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER


def build_basic_sheet(wb):
    ws = wb.active
    ws.title = "基础信息"
    headers = ["字段", "填写值", "状态", "来源", "备注"]
    for col, name in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=name)
    style_header_row(ws, 1, len(headers))
    row = 2
    for field, value, note in BASIC_FIELDS:
        if value is None and note is None:  # 分组行
            cell = ws.cell(row=row, column=1, value=field)
            cell.fill = GROUP_FILL
            cell.font = GROUP_FONT
            for col in range(1, len(headers) + 1):
                ws.cell(row=row, column=col).border = BORDER
            row += 1
            continue
        ws.cell(row=row, column=1, value=field).font = BODY_FONT
        ws.cell(row=row, column=2, value=value)
        status = ws.cell(row=row, column=3, value="待确认")
        status.font = BODY_FONT
        ws.cell(row=row, column=4, value="")
        ws.cell(row=row, column=5, value=note)
        for col in range(1, len(headers) + 1):
            ws.cell(row=row, column=col).border = BORDER
            ws.cell(row=row, column=col).alignment = WRAP
        row += 1
    tip = ws.cell(row=row + 1, column=1,
                  value="填写说明：状态只允许「待确认/已确认/冲突」；AI 提取行会填来源（文件名），人工核实后请改为「已确认」；"
                        "报告起草只使用「已确认」行的值。")
    tip.font = TIP_FONT
    widths = [26, 34, 10, 22, 36]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    return ws


def build_ledger_sheet(wb):
    ws = wb.create_sheet("事实账本")
    for col, name in enumerate(LEDGER_HEADERS, 1):
        ws.cell(row=1, column=col, value=name)
    style_header_row(ws, 1, len(LEDGER_HEADERS))
    example = ws.cell(row=2, column=1, value="示例：A-001")
    example.font = TIP_FONT
    ws.cell(row=2, column=2, value="高标准农田面积").font = TIP_FONT
    ws.cell(row=2, column=3, value=1200).font = TIP_FONT
    ws.cell(row=2, column=4, value="亩").font = TIP_FONT
    # 状态带"示例"字样：校验脚本按精确三态匹配，示例行不会被当作真实账目
    ws.cell(row=2, column=5, value="confirmed（示例行，登记真实数据时请删除本行）").font = TIP_FONT
    ws.cell(row=2, column=6, value="批复文号.docx 第3页").font = TIP_FONT
    tip = ws.cell(row=4, column=1, value=LEDGER_STATUS_TIP + "；报告正文的每一个数字都必须能在本表找到同值行（完稿跑 check_ledger.py 自动核对）。")
    tip.font = TIP_FONT
    widths = [10, 24, 14, 8, 12, 26, 22, 24]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


def build_todo_sheet(wb):
    ws = wb.create_sheet("待补充清单")
    for col, name in enumerate(TODO_HEADERS, 1):
        ws.cell(row=1, column=col, value=name)
    style_header_row(ws, 1, len(TODO_HEADERS))
    tip = ws.cell(row=3, column=1, value=TODO_STATUS_TIP + "；本清单随报告交付（AI 起草遇缺即登记，完稿时汇总交用户）。")
    tip.font = TIP_FONT
    widths = [26, 24, 26, 10, 24]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    out = Path(sys.argv[1])
    out.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    build_basic_sheet(wb)
    build_ledger_sheet(wb)
    build_todo_sheet(wb)
    wb.save(out)
    print(f"已生成 {out}")


if __name__ == "__main__":
    main()
