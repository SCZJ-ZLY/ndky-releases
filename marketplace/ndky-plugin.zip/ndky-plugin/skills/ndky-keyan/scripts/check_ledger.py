# -*- coding: utf-8 -*-
"""NDKY 数字校验：核对生成文档中的数字与账本（账本.md）的一致性。
用法：python check_ledger.py <项目目录> [--doc <指定docx路径>]
仅用标准库。报告输出到 stdout 与 产出/校验报告.txt。
"""
import re
import sys
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

NUM_UNITS = ["万元", "亿元", "亿元", "亩", "平方米", "㎡", "平方公里", "km²", "公顷",
             "人", "个", "台", "套", "万", "%", "个月", "年", "吨", "万元/年"]
NUM_RE = re.compile(r"(\d[\d,，.]{0,15}(?:\.\d+)?)\s*(万元|亿元|亩|平方米|㎡|平方公里|km²|公顷|人|个|台|套|万|%|个月|年|吨)")


def docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"<w:p[ >]", "\n<w:p ", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    return text


def norm_num(s: str) -> str:
    return s.replace(",", "").replace("，", "").strip()


def parse_ledger(md_path: Path):
    """返回 (confirmed_values, candidate_values)：[(数值串, 单位, 字段名)]"""
    conf, cand = [], []
    for line in md_path.read_text(encoding="utf-8").splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 4 or cells[0] in ("字段", "---", ":--") or set(cells[0]) <= {"-", ":"}:
            continue
        field, value, status = cells[0], cells[1], cells[2].lower()
        for m in NUM_RE.finditer(f"{value}"):
            entry = (norm_num(m.group(1)), m.group(2), field)
            if status.startswith("confirm"):
                conf.append(entry)
            elif status.startswith("cand"):
                cand.append(entry)
    return conf, cand


def extract_doc_numbers(text: str):
    """[(数值串, 单位, 上下文30字)]"""
    out = []
    for m in NUM_RE.finditer(text):
        ctx = text[max(0, m.start() - 30):m.end()].replace("\n", " ")
        out.append((norm_num(m.group(1)), m.group(2), ctx))
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    proj = Path(sys.argv[1])
    ledger = proj / "账本.md"
    if not ledger.exists():
        print(f"!! 找不到账本：{ledger}")
        sys.exit(2)

    docs = []
    if "--doc" in sys.argv:
        docs = [Path(sys.argv[sys.argv.index("--doc") + 1])]
    else:
        docs = sorted((proj / "产出").glob("*.docx"))
    if not docs:
        print("!! 产出/ 下没有 docx（可用 --doc 指定）")
        sys.exit(2)

    conf, cand = parse_ledger(ledger)
    conf_keys = {(n, u) for n, u, _ in conf}
    lines = [f"# 数字校验报告  账本: confirmed={len(conf)} candidate={len(cand)}"]

    for doc in docs:
        nums = extract_doc_numbers(docx_text(doc))
        lines.append(f"\n## {doc.name}：提取数字 {len(nums)} 处")
        # 1) 候选值被当定论使用（最严重）
        cand_used = [c for c in nums if (c[0], c[1]) in {(n, u) for n, u, _ in cand} and "待确认" not in c[2]]
        # 2) 文档中账本没有的数字（疑似编造或未入账）
        unknown = [c for c in nums if (c[0], c[1]) not in conf_keys and (c[0], c[1]) not in {(n, u) for n, u, _ in cand}]
        # 3) confirmed 数字未被使用（提示，不算错）
        used_keys = {(c[0], c[1]) for c in nums}
        unused = [e for e in conf if (e[0], e[1]) not in used_keys]

        if cand_used:
            lines.append(f"  [严重] 候选值被当定论使用 {len(cand_used)} 处：")
            lines += [f"    - {n}{u} | 上下文: …{ctx}" for n, u, ctx in cand_used[:20]]
        if unknown:
            lines.append(f"  [警告] 账本外的数字 {len(unknown)} 处（编造或漏登记）：")
            lines += [f"    - {n}{u} | 上下文: …{ctx}" for n, u, ctx in unknown[:30]]
        if unused:
            lines.append(f"  [提示] 账本 confirmed 值未出现在文档 {len(unused)} 项（确认是否该用）：")
            lines += [f"    - {n}{u} ← {f}" for n, u, f in unused[:20]]
        if not (cand_used or unknown or unused):
            lines.append("  ✓ 全部一致")

    report = "\n".join(lines)
    print(report)
    out = proj / "产出" / "校验报告.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    print(f"\n已写入 {out}")


if __name__ == "__main__":
    main()
