# -*- coding: utf-8 -*-
"""NDKY 数字校验：核对生成文档中的数字与项目数据源的一致性（0.4.0）。

数据源自动识别：
- v2 标准化工作区：（2）项目基础信息/项目基础信息.xlsx
  读「基础信息」sheet（已确认行）与「事实账本」sheet（confirmed 行）作为 confirmed；
  待确认行作为 candidate。
- v1 旧工作区：账本.md（原逻辑不变）。

用法：python check_ledger.py <项目目录> [--doc <指定docx路径>]
依赖：v2 模式需要 openpyxl（官方 xlsx 技能环境自带）；v1 模式仅标准库。
报告输出到 stdout 与产出目录（v2:（2）项目基础信息/；v1: 产出/）。
"""
import re
import sys
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

NUM_RE = re.compile(r"(\d[\d,，.]{0,15}(?:\.\d+)?)\s*(万元|亿元|亩|平方米|㎡|平方公里|km²|公顷|人|个|台|套|万|%|个月|年|吨)")

V2_XLSX_REL = Path("（2）项目基础信息") / "项目基础信息.xlsx"
V2_OUTPUT_DIR = Path("（2）项目基础信息")
V1_OUTPUT_DIR = Path("产出")


def docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"<w:p[ >]", "\n<w:p ", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    return text


def norm_num(s: str) -> str:
    return s.replace(",", "").replace("，", "").strip()


def cell_text(value) -> str:
    return str(value).strip() if value is not None else ""


def load_v2_ledger(xlsx_path: Path):
    """返回 (confirmed, candidate, warnings)：[(数值串, 单位, 字段名)]"""
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("!! v2 模式需要 openpyxl（请在官方 xlsx 技能环境/已装 openpyxl 的 python 下运行）")
        sys.exit(2)

    warnings = []
    wb = load_workbook(xlsx_path, read_only=True, data_only=True)
    conf, cand = [], []
    unit_in_name = re.compile(r"[（(]([^（）()]+)[）)]\s*$")

    def status_bucket(status: str):
        status = status.strip().lower()
        if status in ("已确认", "confirmed"):
            return "confirmed"
        if status in ("待确认", "candidate"):
            return "candidate"
        if status in ("冲突", "conflict"):
            return "conflict"
        return None

    def add_entry(value: str, unit: str, name: str, bucket: str):
        for m in NUM_RE.finditer(value):
            entry = (norm_num(m.group(1)), m.group(2), name)
            (conf if bucket == "confirmed" else cand).append(entry)
            return
        # 值列是裸数字（单位在字段名括号里）的兜底：字段名末尾括号抓单位
        naked = norm_num(value)
        if naked and unit_in_name.search(name):
            entry = (naked, unit_in_name.search(name).group(1).strip(), name)
            (conf if bucket == "confirmed" else cand).append(entry)

    # 基础信息 sheet：A 字段 / B 填写值 / C 状态 / D 来源 / E 备注
    if "基础信息" in wb.sheetnames:
        for row in wb["基础信息"].iter_rows(min_row=2, values_only=True):
            name = cell_text(row[0]) if len(row) > 0 else ""
            value = cell_text(row[1]) if len(row) > 1 else ""
            bucket = status_bucket(cell_text(row[2]) if len(row) > 2 else "")
            if not bucket or not name or not value:
                continue
            if name.startswith(("示例", "填写说明")):
                continue
            add_entry(value, "", name, bucket)

    # 事实账本 sheet：A 编号 / B 字段 / C 数值 / D 单位 / E 状态 / F 来源 / G 使用位置 / H 备注
    if "事实账本" in wb.sheetnames:
        for row in wb["事实账本"].iter_rows(min_row=2, values_only=True):
            if len(row) < 5:
                continue
            name = cell_text(row[1])
            bucket = status_bucket(cell_text(row[4]))
            if not bucket or not name or name.startswith("示例"):
                continue
            value = cell_text(row[2])
            unit = cell_text(row[3])
            for m in NUM_RE.finditer(f"{value}{unit}"):
                entry = (norm_num(m.group(1)), m.group(2), name)
                (conf if bucket == "confirmed" else cand).append(entry)
                break
            else:
                add_entry(value, unit, name, bucket)

    wb.close()
    return conf, cand, warnings


def parse_ledger_v1(md_path: Path):
    """v1 账本.md：返回 (confirmed_values, candidate_values, warnings)"""
    conf, cand = [], []
    for line in md_path.read_text(encoding="utf-8").splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 4 or cells[0] in ("字段", "---", ":--") or set(cells[0]) <= {"-", ":"}:
            continue
        field, value, status = cells[0], cells[1], cells[2].lower()
        for m in NUM_RE.finditer(f"{value}"):
            entry = (norm_num(m.group(1)), m.group(2), field)
            if status.startswith("confirm"):
                conf.append(entry)
            elif status.startswith("cand"):
                cand.append(entry)
    return conf, cand, []


def extract_doc_numbers(text: str):
    """[(数值串, 单位, 上下文30字)]"""
    out = []
    for m in NUM_RE.finditer(text):
        ctx = text[max(0, m.start() - 30):m.end()].replace("\n", " ")
        out.append((norm_num(m.group(1)), m.group(2), ctx))
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    proj = Path(sys.argv[1])

    # 数据源自动识别：v2 xlsx 优先，回退 v1 账本.md
    xlsx = proj / V2_XLSX_REL
    ledger_md = proj / "账本.md"
    if xlsx.exists():
        conf, cand, warnings = load_v2_ledger(xlsx)
        source_label = f"v2 基础信息表：{xlsx.name}"
        output_dir = proj / V2_OUTPUT_DIR
    elif ledger_md.exists():
        conf, cand, warnings = parse_ledger_v1(ledger_md)
        source_label = "v1 账本.md"
        output_dir = proj / V1_OUTPUT_DIR
    else:
        print(f"!! 找不到数据源：{V2_XLSX_REL} 或 账本.md（{proj}）")
        sys.exit(2)

    docs = []
    if "--doc" in sys.argv:
        docs = [Path(sys.argv[sys.argv.index("--doc") + 1])]
    else:
        for candidate_dir in (proj / V1_OUTPUT_DIR, proj / V2_OUTPUT_DIR, proj):
            docs = sorted(candidate_dir.glob("*.docx"))
            if docs:
                break
    docs = [d for d in docs if not d.name.startswith("~$")]
    if not docs:
        print("!! 没有找到待校验 docx（可用 --doc 指定）")
        sys.exit(2)

    conf_keys = {(n, u) for n, u, _ in conf}
    lines = [f"# 数字校验报告  数据源: {source_label}  confirmed={len(conf)} candidate={len(cand)}"]

    for w in warnings:
        lines.append(f"  [冲突] {w}")

    for doc in docs:
        nums = extract_doc_numbers(docx_text(doc))
        lines.append(f"\n## {doc.name}：提取数字 {len(nums)} 处")
        cand_used = [c for c in nums if (c[0], c[1]) in {(n, u) for n, u, _ in cand} and "待确认" not in c[2]]
        unknown = [c for c in nums if (c[0], c[1]) not in conf_keys and (c[0], c[1]) not in {(n, u) for n, u, _ in cand}]
        used_keys = {(c[0], c[1]) for c in nums}
        unused = [e for e in conf if (e[0], e[1]) not in used_keys]

        if cand_used:
            lines.append(f"  [严重] 待确认值被当定论使用 {len(cand_used)} 处：")
            lines += [f"    - {n}{u} | 上下文: …{ctx}" for n, u, ctx in cand_used[:20]]
        if unknown:
            lines.append(f"  [警告] 数据源之外的数字 {len(unknown)} 处（编造或漏登记）：")
            lines += [f"    - {n}{u} | 上下文: …{ctx}" for n, u, ctx in unknown[:30]]
        if unused:
            lines.append(f"  [提示] confirmed 值未出现在文档 {len(unused)} 项（确认是否该用）：")
            lines += [f"    - {n}{u} ← {f}" for n, u, f in unused[:20]]
        if not (cand_used or unknown or unused):
            lines.append("  ✓ 全部一致")

    report = "\n".join(lines)
    print(report)
    output_dir.mkdir(parents=True, exist_ok=True)
    out = output_dir / "校验报告.txt"
    out.write_text(report, encoding="utf-8")
    print(f"\n已写入 {out}")


if __name__ == "__main__":
    main()
