# -*- coding: utf-8 -*-
"""NDKY 字数与数据状态统计（0.5.1）：为 进度.md 的「当前统计」区供数。

统计内容：
- 产出 docx：全书/各章中文字数与总字符数（章节按 docx 内 Heading 1 切分；无样式文档按"第X章"文本行切分）；
- xlsx 数据状态：基础信息（已确认/待确认/冲突）与事实账本（confirmed/candidate/conflict）计数、待补充清单条数；
- v1 旧项目自动回退：读 账本.md 三态计数。

用法：python count_words.py <项目目录> [--doc <指定docx路径>]
依赖：docx 解析仅标准库；xlsx 状态计数需 openpyxl（缺失时跳过并提示）。
输出：stdout 统计块（可直接粘贴进 进度.md「当前统计」区）。
"""
import re
import sys
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

V2_XLSX_REL = Path("（3）项目基础信息") / "项目基础信息.xlsx"
V1_XLSX_REL = Path("（2）项目基础信息") / "项目基础信息.xlsx"
DOC_DIRS = [Path("（4）产出"), Path("产出")]
CHAPTER_RE = re.compile(r"^\s*第[一二三四五六七八九十百0-9]+章")


def iter_docx_paragraphs(path: Path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"<w:p[ >]", "\n<w:p ", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    for line in text.split("\n"):
        line = line.strip()
        if line:
            yield line


def split_chapters(path: Path):
    """[(章名, 文本)]；切分点=Heading1 样式或"第X章"文本。无切分点时整篇为一章。"""
    chapters = []
    current_name, buffer = None, []
    for line in iter_docx_paragraphs(path):
        is_chapter_start = CHAPTER_RE.match(line) is not None
        if is_chapter_start:
            if current_name or buffer:
                chapters.append((current_name or "开篇", "\n".join(buffer)))
            current_name, buffer = line[:40], [line]
        else:
            buffer.append(line)
    if current_name or buffer:
        chapters.append((current_name or "正文", "\n".join(buffer)))
    return chapters or [("正文", "\n".join(iter_docx_paragraphs(path)))]


def count_text(text: str):
    """(中文字数, 总非空白字符数)"""
    chinese = len(re.findall(r"[\u4e00-\u9fff]", text))
    total = len(re.sub(r"\s", "", text))
    return chinese, total


def fmt(n: int) -> str:
    return f"{n:,}"


def count_doc(path: Path):
    chapters = split_chapters(path)
    book_cn = book_total = 0
    lines = []
    for name, text in chapters:
        cn, total = count_text(text)
        book_cn += cn
        book_total += total
        lines.append((name, cn, total))
    return book_cn, book_total, lines


def xlsx_status_counts(xlsx_path: Path):
    from openpyxl import load_workbook

    wb = load_workbook(xlsx_path, read_only=True, data_only=True)
    counts = {"基础信息": {}, "事实账本": {}, "待补充清单": 0}

    def norm(v):
        return str(v).strip().lower() if v is not None else ""

    if "基础信息" in wb.sheetnames:
        for row in wb["基础信息"].iter_rows(min_row=2, values_only=True):
            s = norm(row[2]) if len(row) > 2 else ""
            if s in ("已确认", "confirmed"):
                counts["基础信息"]["已确认"] = counts["基础信息"].get("已确认", 0) + 1
            elif s in ("待确认", "candidate"):
                counts["基础信息"]["待确认"] = counts["基础信息"].get("待确认", 0) + 1
            elif s in ("冲突", "conflict"):
                counts["基础信息"]["冲突"] = counts["基础信息"].get("冲突", 0) + 1
    if "事实账本" in wb.sheetnames:
        for row in wb["事实账本"].iter_rows(min_row=2, values_only=True):
            s = norm(row[4]) if len(row) > 4 else ""
            if s.startswith("confirmed"):
                counts["事实账本"]["confirmed"] = counts["事实账本"].get("confirmed", 0) + 1
            elif s.startswith("candidate"):
                counts["事实账本"]["candidate"] = counts["事实账本"].get("candidate", 0) + 1
            elif s.startswith("conflict"):
                counts["事实账本"]["conflict"] = counts["事实账本"].get("conflict", 0) + 1
    if "待补充清单" in wb.sheetnames:
        counts["待补充清单"] = sum(
            1
            for row in wb["待补充清单"].iter_rows(min_row=2, values_only=True)
            if row and cell_any(row)
        )
    wb.close()
    return counts


def cell_any(row):
    return any(str(v).strip() for v in row if v is not None)


def ledger_md_counts(md_path: Path):
    counts = {"confirmed": 0, "candidate": 0, "conflict": 0}
    for line in md_path.read_text(encoding="utf-8").splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 3 or set(cells[0]) <= {"-", ":"} or cells[0] == "字段":
            continue
        s = cells[2].lower()
        if s.startswith("confirm"):
            counts["confirmed"] += 1
        elif s.startswith("cand"):
            counts["candidate"] += 1
        elif s.startswith("conflict"):
            counts["conflict"] += 1
    return counts


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    proj = Path(sys.argv[1])

    docs = []
    if "--doc" in sys.argv:
        docs = [Path(sys.argv[sys.argv.index("--doc") + 1])]
    else:
        for d in DOC_DIRS:
            docs = sorted((proj / d).glob("*.docx")) if (proj / d).exists() else []
            if docs:
                break
    docs = [d for d in docs if not d.name.startswith("~$")]

    print("## 当前统计")
    if docs:
        book_cn = book_total = 0
        for doc in docs:
            cn, total, chapter_lines = count_doc(doc)
            book_cn += cn
            book_total += total
            print(f"\n### {doc.name}：中文 {fmt(cn)} 字 / 总字符 {fmt(total)}")
            multi = len(chapter_lines) > 1
            for name, c, t in chapter_lines:
                if multi:
                    print(f"- {name}：中文 {fmt(c)} 字 / 总字符 {fmt(t)}")
    else:
        print("\n（尚无产出 docx）")

    xlsx = proj / V2_XLSX_REL if (proj / V2_XLSX_REL).exists() else proj / V1_XLSX_REL
    ledger_md = proj / "账本.md"
    try:
        if xlsx.exists():
            c = xlsx_status_counts(xlsx)
            print("\n### 数据状态（xlsx）")
            print(f"- 基础信息：已确认 {c['基础信息'].get('已确认', 0)} / 待确认 {c['基础信息'].get('待确认', 0)} / 冲突 {c['基础信息'].get('冲突', 0)}")
            print(f"- 事实账本：confirmed {c['事实账本'].get('confirmed', 0)} / candidate {c['事实账本'].get('candidate', 0)} / conflict {c['事实账本'].get('conflict', 0)}")
            print(f"- 待补充清单：{c['待补充清单']} 项")
        elif ledger_md.exists():
            c = ledger_md_counts(ledger_md)
            print("\n### 数据状态（v1 账本.md）")
            print(f"- confirmed {c['confirmed']} / candidate {c['candidate']} / conflict {c['conflict']}")
        else:
            print("\n（未找到数据源 xlsx/账本.md）")
    except ImportError:
        print("\n（xlsx 状态计数需要 openpyxl，本次跳过）")


if __name__ == "__main__":
    main()
